from helpers import *
from app import *
from app.Models import *
from flask.views import MethodView
from werkzeug.utils import secure_filename
from flask import current_app, Blueprint
from datetime import datetime
CRForm_view = Blueprint('cr_form_view', __name__)


class CreateCRForm(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/add_cr_form.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            form_name = request_data['form_name']
            form_shortcode = request_data['form_shortcode']
            form_description = request_data['form_description']
            form_heading = request_data['form_heading']
            form_slug = request_data['form_slug']
            form_sub_heading = request_data['form_sub_heading']
            status = request_data['status']
            cr_forms.Add_cr_form(form_name, form_shortcode, form_description, form_heading, form_slug, form_sub_heading,
                                 status)
            response = {
                "status": "success",
                "message": "CR Form created successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200

def form_permit(U):
    @wraps(U)
    def wrapper(*args, **kwargs):
        token = request.headers.get('token')
        request_data = request.form
        try:
            decoded_token = jwt.decode(token, current_app.config['USER_SECRET_KEY'], algorithms=['HS256'])
            print(decoded_token)
            # email = decoded_token['email']
            print("hello")
            # po_number = request_data["po_number"]
            cr_code = request_data.get('cr_code', None)

            print(cr_code)
            if not cr_code:
                form_id = request_data['form_id']
                form_shortcode = cr_forms.Fetch_cr_form_by_id(int(form_id))["form_shortcode"]
                costcenter = request_data.get('costcenter')
            else:
                form_shortcode = cr_code.split("_", 2)[1]
                costcenter = Cr_info.Fetch_cr_info(cr_code)[0]["cost_center"]
            CrFormMaster(form_shortcode, cr_code)

            # if email in Cache.cache.keys() and Cache.get(email) == token:
            init_by = Users.FetchUSerDetails_By_ID(decoded_token["id"])["employee_id"]
            print(init_by)
            # init_by = '415378'
            print("user Verified", init_by, CrFormMaster(form_shortcode, cr_code))
            # costcenter = request_data.get('costcenter', Cr_info.Fetch_cr_info(cr_code)[0]["cost_center"])

            print(costcenter, "11232")
            if Users.FetchUSerDetails_By_ID(decoded_token["id"])["role_id"]== 1:
                    print("Access granted")
                    return U(*args, **kwargs)
            
            if cr_code:
                #elif Users.FetchUSerDetails_By_ID(decoded_token["id"])["role_id"] != 1:
                form_id = request_data.get('form_id', Cr_info.Fetch_cr_info(cr_code)[0]["form_id"])
                Cr_info.Fetch_cr_info(cr_code)
                print("current state", [each["state"] for each in Cr_info.Fetch_cr_info(cr_code)][0])
                present_state = [each["state"] for each in Cr_info.Fetch_cr_info(cr_code)]
                present_status = [each["status"] for each in Cr_info.Fetch_cr_info(cr_code)]
                print("current state", present_state)
                print("current status", present_status)
                next = finite_state_machine(present_state[0], permit(costcenter))
                print("next assignee", next)
                # print(present_status)
                if present_status:
                    if present_status[0] != "correction" or present_status[0] == "completed":
                        print("admin role",Users.FetchUSerDetails_By_ID(decoded_token["id"])["role_id"])
                        if init_by in next["next_list"] or \
                                Users.FetchUSerDetails_By_ID(decoded_token["id"])["role_id"] == '1':
                            print("Access granted", next["next_list"], next["next_state"])
                            return U(*args, **kwargs)
                        else:
                            return jsonify({"AUTH ERROR": "USER AUTHORISATION REQUIRED"}), 401
                    if present_status[0] == "correction":
                        # print("pre_list", next["previous_list"])
                        if init_by in next["previous_list"] or \
                                Users.FetchUSerDetails_By_ID(decoded_token["id"])["role_id"] == 1:
                            print("Access granted cause last state is correction", next["previous_list"],
                                  next["previous_state"])
                            return U(*args, **kwargs)
                        else:
                            return jsonify({"AUTH ERROR": "USER AUTHORISATION REQUIRED"}), 401
                    else:
                        if (init_by in next["previous_list"] and present_status[0] == "correction") \
                                or Users.FetchUSerDetails_By_ID(decoded_token["id"])["role_id"] == 1:
                            print("Access granted")
                            return U(*args, **kwargs)
                        else:
                            return jsonify({"AUTH ERROR": "USER AUTHORISATION REQUIRED"}), 401
                            
            
            elif not Cr_info.Fetch_cr_info(CrFormMaster(form_shortcode, cr_code)):
                # costcenter = CrFormMaster(form_shortcode, cr_code)
                print("permit level not", permit(costcenter))
                Cr_info.Fetch_cr_info(cr_code)
                # print("Cr_info", [each["state"] for each in Cr_info.Fetch_cr_info(cr_code)])
                # present_state = [each["state"] for each in Cr_info.Fetch_cr_info(cr_code)]
                print(finite_state_machine("clms_nodal_user", permit(costcenter)))
                if init_by in permit(costcenter)["clms_nodal_user"]:
                    print("Access granted", permit(costcenter)["clms_nodal_user"])
                    return U(*args, **kwargs)
                else:
                    print(1)
                    return jsonify({"AUTH ERROR": "USER AUTHORISATION REQUIRED"}), 401
            else:
                import traceback
                traceback.print_exc()
                print(2)
                print(Cr_info.Fetch_cr_info(CrFormMaster(form_shortcode, cr_code)))
                return jsonify({"AUTH ERROR": "USER AUTHORISATION REQUIRED"}), 401
        except:
            import traceback
            traceback.print_exc()
            print(3)
            return jsonify({"AUTH ERROR": "USER AUTHORISATION REQUIRED"}), 401

    return wrapper


class CreateCRForminit(MethodView):
    # @user_Required
    @form_permit
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/create_cr_form.yaml', methods=['POST'])
    def post(self):
        try:
            token = request.headers.get('token')
            decoded_token = jwt.decode(token, current_app.config['USER_SECRET_KEY'], algorithms=['HS256'])
            # print(decoded_token)
            next_as = None
            request_data = request.form
            cr_code = request_data.get('cr_code', None)
            print(request_data.get('costcenter'))
            if int(decoded_token["id"]) != 1:
                designation_id = Users.FetchUSerDetails_By_ID(int(decoded_token["id"]))["designation_id"]
                designation = Designations.FetchDesignationDetails_By_ID(designation_id)["name"]
                print(designation, "designation")

            # print(Users.FetchUSerDetails_By_ID(int(decoded_token["id"]))["employee_id"])
            # form_id = request_data['form_id']
            # form_shortcode = cr_forms.Fetch_cr_form_by_id(int(form_id))["form_shortcode"]
            # CrFormMaster(form_shortcode, cr_code)
            # form_id = request_data.get('form_id', Cr_info.Fetch_cr_info(cr_code)[0]["form_id"])
            if not cr_code:
                form_id = request_data.get('form_id')
                costcenter = request_data.get('costcenter')
                po_number = request_data.get("po_number")
                form_shortcode = cr_forms.Fetch_cr_form_by_id(int(form_id))["form_shortcode"]
                dept = request_data.get('department')
                yard_no = request_data.get('yard_no')
                unit = request_data.get('unit')
                status = request_data.get("status")
            else:
                po_number = Cr_info.Fetch_cr_info(cr_code)[0]["po_number"]
                form_id = Cr_info.Fetch_cr_info(cr_code)[0]["form_id"]
                costcenter = Cr_info.Fetch_cr_info(cr_code)[0]["cost_center"]
                form_shortcode = cr_code.split("_", 2)[1]
                dept = Cr_info.Fetch_cr_info(cr_code)[0]["dept"]
                yard_no = Cr_info.Fetch_cr_info(cr_code)[0]["yard_no"]
                unit = Cr_info.Fetch_cr_info(cr_code)[0]["unit"]
                status = request_data.get("status", Cr_info.Fetch_cr_info(cr_code)[0]["status"])
                initiated_by = Cr_info.Fetch_cr_info_first(cr_code)
            CrFormMaster(form_shortcode, cr_code)

            # form_state = request_data["form_state"]
            init_by = Users.FetchUSerDetails_By_ID(int(decoded_token["id"]))["employee_id"]  # need to take from JWT
            form_status = request_data.get("form_status", "pending")
            # status = request_data.get("status", Cr_info.Fetch_cr_info(cr_code)[0]["status"])
            # unit = request_data.get('unit', Cr_info.Fetch_cr_info(cr_code)[0]["unit"])
            # po_number = request_data.get("po_number", Cr_info.Fetch_cr_info(cr_code)[0]["po_number"])
            attachment_code = request_data.get("attachment_code", None)
            if "dcode_details" in request_data.keys():
                dcode_details = json.loads(request_data.get("dcode_details", None))
            # print(request_data)
            # print(request.files)
            file_name = request.files.getlist('file[]')
            # print(file_name)
            # for file in file_name:
            #     print(file)

            # filename = secure_filename(file_name.filename)
            # path = save_file(file_name, filename)
            present_status = [each["status"] for each in Cr_info.Fetch_cr_info(cr_code)]
            present_state = [each["state"] for each in Cr_info.Fetch_cr_info(cr_code)]
            if present_state:
                if present_status[0] != "correction" and present_status[0] != "rejected":
                    if present_status[0] == "complete" and present_state[0] == 'clms_nodal_secu':
                        if Users.FetchUSerDetails_By_ID(decoded_token["id"])["role_id"] == 1:
                            Cr_info.Add_cr_info(dept, yard_no, initiated_by, unit, po_number,
                                                costcenter,
                                                "complete", form_id, CrFormMaster(form_shortcode, cr_code), "Admin",
                                                "Admin",
                                                "onboard",
                                                Users.FetchUSerDetails_By_ID(decoded_token["id"])["employee_id"],
                                            datetime.now(), 1 if form_status == "rejected" else 0, init_by,request_data.get("remark", None))
                            # final onboard
                            onboard = onboard_form(CrFormMaster(form_shortcode, cr_code), request_data)
                            print("here", onboard)
                            response = {
                                "status": "success",
                                "message": "Approved by Admin",
                                "output": onboard
                            }
                            print(response)
                            return make_response(jsonify(response)), 200
                        else:
                            response = {
                                "status": "error",
                                "message": "Admin Approval required"}
                            print(response)
                            return make_response(jsonify(response)), 200

                    else:
                        next_as = finite_state_machine(present_state[0], permit(costcenter))["next_state"]
                        print(present_state[0], "next state", next_as)
                elif present_status[0] == "correction":
                    next_as = finite_state_machine(present_state[0], permit(costcenter))["previous_state"]
                    print(present_state[0], "previous state", next_as)
                else:
                    next_as = finite_state_machine("clms_nodal_user", permit(costcenter))

            user_permit = Department.get_department_by_costcenter(costcenter)
            print("permit level", permit(costcenter))
            if "dcode_details" in request_data.keys():
                for each in json.loads(dcode_details):
                    if each["dcode"] and CrFormMaster(form_shortcode, cr_code):
                        # print("form_shortcode", form_shortcode, each)
                        cr_dd.update_by_form_id(CrFormMaster(form_shortcode, cr_code), each["dcode"])

                        cr_dd.Add_cr_dd(each["dcode"], each["d_value"], init_by, request_data.get("remark", None),
                                        init_by + "_" + each["dcode"] + "_" + str(datetime.now().date()),
                                        init_by, CrFormMaster(form_shortcode, cr_code), "active")
                    else:
                        cr_dd.Add_cr_dd(each["dcode"], each["d_value"], init_by, request_data.get("remark", None),
                                        init_by + "_" + each["dcode"] + "_" + str(datetime.now().date()),
                                        init_by, CrFormMaster(form_shortcode, cr_code), "active")

            if attachment_code:
                for code, file in zip(json.loads(json.loads(attachment_code)), file_name):
                    filename = secure_filename(file.filename)
                    # print(filename.split(".")[1])
                    # print(CrFormMaster(form_shortcode, cr_code) + "_" +
                    # str(datetime.datetime.now()).replace(" ", "_") + "." + filename.split(".")[1])
                    if filename:
                        path = save_file(file, CrFormMaster(form_shortcode, cr_code) + "_" +
                                         str(datetime.now()).replace(" ", "_") + "." + filename.split(".")[1])
                    if cr_code:
                        media_doc.update_by_form_id(CrFormMaster(form_shortcode, cr_code), code["a_code"])

                        media_doc.Add_media_doc(cr_code + str(datetime.now()).replace(" ", "_"), code["details"],
                                                path.get("message", None),
                                                CrFormMaster(form_shortcode, cr_code),
                                                init_by, "active")
                    else:
                        media_doc.Add_media_doc(
                            CrFormMaster(form_shortcode, cr_code) + str(datetime.now()).replace(" ", "_"),
                            code["details"],
                            path.get("message", None),
                            CrFormMaster(form_shortcode, cr_code),
                            init_by, "active")
            if not cr_code:
                Cr_info.Add_cr_info(dept, yard_no, init_by, unit, po_number,
                                    costcenter,
                                    status, form_id, CrFormMaster(form_shortcode, cr_code),designation,
                                    "clms_nodal_user",
                                    form_status, None, None, 0,init_by,request_data.get("remark", None))
            elif cr_code and form_status == "rejected":
                Cr_info.update_by_form_id(CrFormMaster(form_shortcode, cr_code), form_status,
                                          1 if form_status == "rejected" else 0)
                print("next as", next_as)
                Cr_info.Add_cr_info(dept, yard_no, initiated_by, unit, po_number,
                                    costcenter,
                                    "rejected", form_id, CrFormMaster(form_shortcode, cr_code), designation, next_as,
                                    "rejected",
                                    None, None, 1, init_by,request_data.get("remark", None))

            elif cr_code and next_as == "clms_nodal_secu" and status == "complete":
                Cr_info.Add_cr_info(dept, yard_no, initiated_by, unit, po_number,
                                    costcenter,
                                    status, form_id, CrFormMaster(form_shortcode, cr_code), designation, next_as,
                                    "complete",
                                    None, None, 0, init_by,request_data.get("remark", None))
            else:
                # Cr_info.update_by_form_id(CrFormMaster(form_shortcode, cr_code), form_status,
                #                           1 if form_status == "rejected" else 0)
                Cr_info.Add_cr_info(dept, yard_no, init_by if not initiated_by else initiated_by, unit, po_number,
                                    costcenter,
                                    status, form_id, CrFormMaster(form_shortcode, cr_code), designation, next_as,
                                    form_status,
                                    None,
                                    None, 1 if form_status == "rejected" else 0, init_by,request_data.get("remark", None))
            response = {
                "status": "success",
                "message": "CR Form submitted successfully by " + next_as if next_as else "CR Form submitted successfully by clms_nodal_user"}
            print(response)
            return make_response(jsonify(response)), 200

        except Exception as e:
            import traceback
            traceback.print_exc()
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200

class ViewCRForm(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/view_cr_form.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            cr_code = request_data['cr_code']
            if len(Cr_info.Fetch_cr_info(cr_code)) != 0:
                output = Cr_info.Fetch_cr_info(cr_code)[0]
                output["po_date"] = po_master.Fetch_po_with_po_number(output.get("po_number")).get("po_date")
                output["form_type"] = cr_forms.Fetch_cr_form(cr_code.split("_", 2)[1])
                output["doc_details"] = media_doc.get_document_by_form_id(cr_code)
                output["form_details"] = form_details(cr_code)
                output["last_submitted"] = last_submitted(cr_code)
                output["next_assigne"] = next_assigne(cr_code)
                output["form_log"] = form_state(cr_code)
                output["form_state"] = state_machine(cr_code)
                output["remark"] = fetch_remark(cr_code)
                response = {
                    "status": "success",
                    "message": "CR Form fetched successfully",
                    "Data": output
                }
            else:
                response = {
                    "status": "success",
                    "message": "CR Form data not found",
                    "Data": []
                }
            return make_response(jsonify(response)), 200
        except Exception as e:
            import traceback
            traceback.print_exc()
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200

class CRForminit(MethodView):
    @user_Access
    @cross_origin(supports_credentials=True)
    # @swag_from('apidocs/view_cr_form.yaml', methods=['POST'])
    def post(self):
        try:
            token = request.headers.get('token')
            decoded_token = jwt.decode(token, current_app.config['USER_SECRET_KEY'], algorithms=['HS256'])
            # print(decoded_token)
            submit_form = list()
            query = cr_forms.query.filter(cr_forms.status != "delete").order_by(cr_forms.created_at.desc()).all()
            CRFormSchema = cr_forms_schema(many=True)
            get_cr_forms = CRFormSchema.dump(query)
            _init_by = Users.FetchUSerDetails_By_ID(int(decoded_token["id"]))["employee_id"]
            if int(decoded_token["id"]) != 1:
                designation_id = Users.FetchUSerDetails_By_ID(int(decoded_token["id"]))["designation_id"]
                designation = Designations.FetchDesignationDetails_By_ID(designation_id)["name"]
            query_2 = Cr_info.query.filter_by(init_by=_init_by).all() 
            CrInfoSchema = cr_info_schema(many=True)
            summitted_form = CrInfoSchema.dump(query_2)
            access = list()
            submit_list = list()

            for _form_id in [each["id"] for each in get_cr_forms]:
                
                query_3 = Cr_info.query.filter_by(form_id=str(_form_id)).order_by(Cr_info.created_at.desc()).all()
                CrInfoSchema = cr_info_schema(many=True)
                access_form = CrInfoSchema.dump(query_3)
                form_id_list = list()
                for each in access_form:
                    if each["unique_id"] not in form_id_list:
                        form_id_list.append(each["unique_id"])
                        if each["status"] == "correction":
                            each["edit"] = True if _init_by in \
                                                   finite_state_machine(each["state"], permit(each["cost_center"]))[
                                                       "previous_list"] else False
                                                       
                        else:
                            each["edit"] = True \
                                if _init_by in finite_state_machine(each["state"], permit(each["cost_center"]))[
                                "next_list"] \
                                   and each["status"] != "correction" and each["status"] != "rejected" \
                                   and each["form_status"] != "onboard" else False

                        print(each["edit"])
                        #each["submission_date"]= each["created_at"]
                        new_each = {**each, **cr_forms.Fetch_cr_form_heading_by_id(each['form_id'])}
                        #access.append(each)
                        access.append(new_each)
                        submit_form.append(new_each)
            
            if "employee_id" in decoded_token.keys(): # ignore admin
                permit_ = Department.check_ROW_if_exists_in_Table(str(decoded_token["employee_id"]))
            response = {
                "permission": Department.check_ROW_if_exists_in_Table(str(decoded_token["employee_id"])) if "employee_id" in decoded_token.keys() else False,
                "message": "CR Form fetched successfully",
                "cr_forms": get_cr_forms,  # if permit_ else [],
                "submitted_forms": submit_form,
                "access_form": access
            }
            return make_response(jsonify(response)), 200
        except Exception as e:
            import traceback
            traceback.print_exc()
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200
            
class Forminit(MethodView):
    @user_Access
    @cross_origin(supports_credentials=True)
    # @swag_from('apidocs/view_cr_form.yaml', methods=['POST'])
    def post(self):
        try:
            token = request.headers.get('token')
            request_data = request.get_json(force=True)
            decoded_token = jwt.decode(token, current_app.config['USER_SECRET_KEY'], algorithms=['HS256'])
            _init_by = Users.FetchUSerDetails_By_ID(int(decoded_token["id"]))["employee_id"]
            crgroups = list()
            dm_list = list()
            cr_form = cr_forms.query.filter(cr_forms.form_slug == request_data['slug']). \
                order_by(cr_forms.updated_at.desc()).first()
            CRFormSchema = cr_forms_schema()
            output_form = CRFormSchema.dump(cr_form)
            query = po_master.query.all()
            CrFormGroupSchema = po_master_schema(many=True)
            output_po = CrFormGroupSchema.dump(query)
            query_dept = Department.query.filter(
            (Department.clms_nodal_user == _init_by) | (Department.hod_man == _init_by) | (
                        Department.hod_functional_area == _init_by)).all()
            DeptSchema = Department_schema(many=True)
            output_dept = DeptSchema.dump(query_dept)
            if output_form.get("id"):
                crgroup = cr_form_groups.get_cr_form_by_formid(output_form.get("id"))
                for group in crgroup:
                    # print(group)
                    cr_group_ = cr_groups.Fetch_cr_group_by_groupid(int(group))
                    cr_demong_group = cr_demog_groups.Fetch_cr_demog_group(cr_group_["id"])
                    for demog in cr_demong_group:
                        Demong_master = dm.get_demog_by_id(int(demog))
                        dm_list.append(Demong_master)
                    # print(dm_list)
                    cr_group_["demog_masters"] = dm_list
                    dm_list = []
                    crgroups.append(cr_group_)
            response = {
                "Dept_master": output_dept,
                "message": "CR Form fetched successfully",
                "po_master": output_po if output_po else [],
                "formDetails": output_form if output_form else [],
                "formGroup": crgroups if crgroups else []
            }
            return make_response(jsonify(response)), 200
        except Exception as e:
            import traceback
            traceback.print_exc()
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200

class UpdateCrFormStatus(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/update_cr_form_status.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            _id = request_data["id"]
            status = request_data['status']
            cr_forms.Change_Status(_id, status)
            response = {
                "status": "success",
                "message": "CR Form status updated successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class GetCrForm(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/get_cr_form.yaml', methods=['GET'])
    def get(self, page_no):
        try:
            query = cr_forms.query.filter(cr_forms.status != "delete").order_by(cr_forms.form_name).all()
            CRFormSchema = cr_forms_schema(many=True)
            output = CRFormSchema.dump(query)
            response = {
                "status": "success",
                "message": "PO Master fetched successfully",
                "CRFormList": Paginate(output, page_no) if page_no != "all" else output,
                "SearchCount": len(output)

            }
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class GetCrFormBySlug(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/get_cr_form_by_slug.yaml', methods=['GET'])
    def get(self, slug):
        try:
            print(str(slug))
            crgroups = list()
            dm_list = list()
            cr_form = cr_forms.query.filter(cr_forms.form_slug == slug).order_by(cr_forms.form_name).first()
            CRFormSchema = cr_forms_schema()
            output = CRFormSchema.dump(cr_form)
            if output.get("id") :
                crgroup = cr_form_groups.get_cr_form_by_formid(output.get("id"))
                for group in crgroup:
                    # print(group)
                    cr_group_ = cr_groups.Fetch_cr_group_by_groupid(int(group))
                    cr_demong_group = cr_demog_groups.Fetch_cr_demog_group(cr_group_["id"])
                    # print("cr_demong_group", cr_demong_group)
                    for demog in cr_demong_group:
                        Demong_master = dm.get_demog_by_id(int(demog))
                        dm_list.append(Demong_master)
                    # print(dm_list)
                    cr_group_["demog_masters"] = dm_list
                    dm_list = []
                    crgroups.append(cr_group_)

                print(crgroups)
                response = {
                    "status": "success",
                    "message": "CR Form fetched successfully",
                    "formDetails": output,
                    "formGroup": crgroups
                }
                print(response)
                return make_response(jsonify(response)), 200
            else:
                response = {
                    "status": "error",
                    "message": "Can't fetched CR Form successfully"
                               " Slug not found",
                    "formDetails": [],
                    "formGroup": []
                }
                print(response)
                return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class CreateCRFormGroup(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/add_cr_form_group.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            form_id = request_data["form_id"]
            group_id = request_data["group_id"]  # list
            status = request_data['status']
            cr_form_group = cr_form_groups.query.filter_by(form_id=str(form_id)) \
                .with_entities(cr_form_groups.id).all()
            CRFormGroupSchema = cr_form_groups_schema(many=True)
            output = CRFormGroupSchema.dump(cr_form_group)
            output = [each["id"] for each in output]
            for _each in output:
                cr_form_groups.query.filter_by(id=int(_each)).delete()
                db.session.commit()
            for each in group_id:
                if cr_form_groups.check_cr_form_if_exists_in_group(form_id, each):
                    cr_form_groups.Add_cr_form_group(form_id, each, status)
            response = {
                "status": "success",
                "message": "CR form group created successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class UpdateCrFormGroupStatus(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/update_cr_form_group_status.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            _id = request_data["id"]
            status = request_data['status']
            cr_form_groups.Change_Status(_id, status)
            response = {
                "status": "success",
                "message": "CR Form group status updated successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class UpdateCrFormGroup(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/update_cr_form_group.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            _id = request_data["id"]
            form_id = request_data["form_id"]
            group_id = request_data["group_id"]
            cr_form_groups.Update_cr_form_groups(_id, form_id, group_id)
            response = {
                "status": "success",
                "message": "CR Form group updated successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class GetCrFormGroup(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/get_cr_form_group.yaml', methods=['GET'])
    def get(self, page_no):
        try:
            cr_form_group = cr_form_groups.query.filter(cr_form_groups.status != "delete") \
                .order_by(cr_form_groups.updated_at.desc()).all()
            CRFormGroupSchema = cr_form_groups_schema(many=True)
            output = CRFormGroupSchema.dump(cr_form_group)
            response = {
                "status": "success",
                "message": "CR Form group fetched successfully",
                "CrFormGroupList": Paginate(output, page_no) if page_no != "all" else output,
                "SearchCount": len(output)}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class CreatePOMaster(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/add_po_master.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            po_date = request_data['po_date']
            po_title = request_data.get('po_title', None)
            supplier_code = request_data.get('supplier_code', None)
            assign_date = request_data.get('assign_date', None)
            expiry = request_data.get('expiry', None)
            po_number = request_data['po_number']
            status = request_data['status']
            po_details = request_data.get('po_details', None)
            if po_master.check_cr_form_if_exists_in_po(po_number):
                po_master.Add_po_master(po_number, po_date, po_title, po_details, supplier_code, assign_date, expiry,
                                        status)
                response = {
                    "status": "success",
                    "message": "PO Master created successfully"}
            else:
                response = {
                    "status": "Error",
                    "message": "PO number already exist"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class UpdatePOMasterStatus(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/update_po_master_status.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            _id = request_data["id"]
            status = request_data['status']
            po_master.Change_Status(_id, status)
            response = {
                "status": "success",
                "message": "PO Master status updated successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class UpdatePOMaster(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/update_po_master.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            _id = request_data["id"]
            po_date = request_data['po_date']
            po_title = request_data['po_title']
            supplier_code = request_data['supplier_code']
            assign_date = request_data['assign_date']
            expiry = request_data['expiry']
            po_number = request_data['po_number']
            po_details = request_data['po_details']
            po_master.Update_po_master(_id, po_number, po_date, po_title, po_details, supplier_code, assign_date, expiry)
            response = {
                "status": "success",
                "message": "PO Master updated successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class GetPoMaster(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/get_po_master.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            page_no = request_data["page_no"]
            search = request_data["search"]
            if search:
                if str.isdigit(search):
                    search_query = f"SELECT * FROM po_master WHERE status != 'delete' AND po_number = {search}" \
                                   f" OR po_title ilike'%{search}%'"
                else:
                    search_query = f"SELECT * FROM po_master WHERE status != 'delete' " \
                                   f" AND po_title ilike '%{search}%'"
                data = db.session.execute(search_query)
                POSchema = po_master_schema(many=True)
                output = POSchema.dump(data)
            else:
                query = po_master.query.filter(po_master.status != "delete").order_by(po_master.po_title).all()
                POSchema = po_master_schema(many=True)
                output = POSchema.dump(query)
            response = {
                "status": "success",
                "message": "PO Master fetched successfully",
                "POMasterList": Paginate(output, page_no) if page_no != "all" else output,
                "SearchCount": len(output)

            }
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            import traceback
            traceback.print_exc()
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200

class CreateVendors(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/add_vendors.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            vd_code = request_data['vd_code']
            vd_scrum_id = request_data['vd_scrum_id']
            is_deleted = request_data['is_deleted']
            status = request_data['status']
            name = request_data["name"]
            if vendors.check_cr_form_if_exists_in_vendor(vd_code):
                vendors.Add_vendors(name, vd_code, vd_scrum_id, is_deleted, status)
                response = {
                    "status": "success",
                    "message": "New Vendor added successfully"}
                print(response)
            else:
                response = {
                    "status": "success",
                    "message": "Vendor already exists"}
                print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200

class UpdateVendorStatus(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/update_vendor_status.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            _id = request_data["id"]
            status = request_data['status']
            vendors.Change_Status(_id, status)
            response = {
                "status": "success",
                "message": "Vendor status updated successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class UpdateVendor(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/update_vendor.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            vd_code = request_data['vd_code']
            vd_scrum_id = request_data['vd_scrum_id']
            is_deleted = request_data['is_deleted']
            _id = request_data['id']
            name = request_data["name"]
            vendors.Update_vendors(_id, name, vd_code, vd_scrum_id, is_deleted)
            response = {
                "status": "success",
                "message": "Vendor updated successfully"}
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200


class GetVendor(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/get_vendor.yaml', methods=['GET'])
    def get(self, page_no):
        try:
            query = vendors.query.filter(vendors.status != "delete").order_by(vendors.name).all()
            VendorSchema = vendors_schema(many=True)
            output = VendorSchema.dump(query)
            response = {
                "status": "success",
                "message": "Vendor list fetched successfully",
                "VendorList": Paginate(output, page_no) if page_no != "all" else output,
                "SearchCount": len(output)
            }
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            import traceback
            traceback.print_exc()
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200
            
class GetDemogValueById(MethodView):
    @cross_origin(supports_credentials=True)
    # @swag_from('apidocs/get_vendor.yaml', methods=['GET'])
    def post(self):
        try:
            result = {}
            request_data = request.get_json(force=True)
            unique_id = request_data.get("unique_id")
            dmog_code = request_data.get("demog_code")
            new_list = []
            for each in dmog_code:
                print(cr_dd.get_demog_value_by_demog_id(unique_id, each),"demong_value",each)
                if not cr_dd.get_demog_value_by_demog_id(unique_id, each):
                    pass
                else:
                    new_list.append({"key": each, "value": cr_dd.get_demog_value_by_demog_id(unique_id, each)["d_value"]})
            result["value"] = new_list
            result["form_type"] = unique_id.split("_", 2)[1]
            response = {
                "status": "success",
                "message": "Get Dmong value by Dmong ID",
                "result": result
            }
            print(response)
            return make_response(jsonify(response)), 200
        except Exception as e:
            import traceback
            traceback.print_exc()
            response = {"status": 'Error', "message": f'{str(e)}'}
            print(response)
            return make_response(jsonify(response)), 200

# # # Creating View Function/Resources
CreateCRForm = CreateCRForm.as_view("CreateCRForm")
CreateCRForminit = CreateCRForminit.as_view("CreateCRForminit")
ViewCRForm = ViewCRForm.as_view("ViewCRForm")
CreateCRFormGroup = CreateCRFormGroup.as_view("CreateCRFormGroup")
UpdateCrFormGroupStatus = UpdateCrFormGroupStatus.as_view("UpdateCrFormGroupStatus")
UpdateCrFormGroup = UpdateCrFormGroup.as_view("UpdateCrFormGroup")
GetCrFormGroup = GetCrFormGroup.as_view("GetCrFormGroup")
UpdateCrFormStatus = UpdateCrFormStatus.as_view("UpdateCrFormStatus")
GetCrFormBySlug = GetCrFormBySlug.as_view("GetCrFormBySlug")
GetCrForm = GetCrForm.as_view("GetCrForm")
CreatePOMaster = CreatePOMaster.as_view("CreatePOMaster")
UpdatePOMasterStatus = UpdatePOMasterStatus.as_view("UpdatePOMasterStatus")
UpdatePOMaster = UpdatePOMaster.as_view("UpdatePOMaster")
GetPoMaster = GetPoMaster.as_view("GetPoMaster")
CreateVendors = CreateVendors.as_view("CreateVendors")
UpdateVendorStatus = UpdateVendorStatus.as_view("UpdateVendorStatus")
UpdateVendor = UpdateVendor.as_view("UpdateVendor")
GetVendor = GetVendor.as_view("GetVendor")
CRForminit = CRForminit.as_view("CRForminit")
Forminit = Forminit.as_view("Forminit")
GetDemogValueById = GetDemogValueById.as_view("GetDemogValueById")
# # # adding routes to the Views we just created
CRForm_view.add_url_rule('/cr_form_group', view_func=CreateCRFormGroup, methods=['POST'])
CRForm_view.add_url_rule('/update_cr_form_group_status', view_func=UpdateCrFormGroupStatus, methods=['POST'])
CRForm_view.add_url_rule('/update_cr_form_group', view_func=UpdateCrFormGroup, methods=['POST'])
CRForm_view.add_url_rule('/get_cr_from_group/<page_no>', view_func=GetCrFormGroup, methods=['GET'])
CRForm_view.add_url_rule('/cr_form', view_func=CreateCRForm, methods=['POST'])
CRForm_view.add_url_rule('/cr_form_initiate', view_func=CreateCRForminit, methods=['POST'])
CRForm_view.add_url_rule('/view_cr_form', view_func=ViewCRForm, methods=['POST'])
CRForm_view.add_url_rule('/update_cr_form_status', view_func=UpdateCrFormStatus, methods=["POST"])
CRForm_view.add_url_rule('/get_cr_form_by_slug/<slug>', view_func=GetCrFormBySlug, methods=["GET"])
CRForm_view.add_url_rule('/get_cr_form/<page_no>', view_func=GetCrForm, methods=["GET"])
CRForm_view.add_url_rule('/add_po_master', view_func=CreatePOMaster, methods=["POST"])
CRForm_view.add_url_rule('/update_po_master_status', view_func=UpdatePOMasterStatus, methods=["POST"])
CRForm_view.add_url_rule('/update_po_master', view_func=UpdatePOMaster, methods=['POST'])
CRForm_view.add_url_rule('/get_po_master', view_func=GetPoMaster, methods=['POST'])  # change
CRForm_view.add_url_rule('/add_vendors', view_func=CreateVendors, methods=['POST'])
CRForm_view.add_url_rule('/update_vendor_status', view_func=UpdateVendorStatus, methods=['POST'])
CRForm_view.add_url_rule('/update_vendor', view_func=UpdateVendor, methods=['POST'])
CRForm_view.add_url_rule('/get_vendors/<page_no>', view_func=GetVendor, methods=['GET'])
CRForm_view.add_url_rule("/cr_form_user_initialize", view_func=CRForminit, methods=['POST'])
CRForm_view.add_url_rule("/form_initialize", view_func=Forminit, methods=['POST'])
CRForm_view.add_url_rule('/get_dvalue_by_dcode', view_func=GetDemogValueById, methods=['POST'])

