import json
from app import *
import requests
import Settings.config
from app.Models import *


def Login_cookie():
    try:
        userId = Settings.config.Alpeta_Login_Id
        password = Settings.config.Alpeta_Login_Password
        user_type = Settings.config.Alpeta_Login_UserType
        params = {"userId": userId, "password": password, "userType": user_type}
        req = requests.post(url=Settings.config.base_url + '/login', json=params)
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        cookie = req.cookies
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                return cookie
            else:
                return {'status': 'error', "message": 'alpetaServerLogin Rejected. Error Code: ' + str(ResultCode)}
        else:
            resp = {"status": 'error', "message": 'Something went wrong in alpetaServerLogin'}
            return resp
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServerLogin'}
        return resp


def get_terminals():
    try:
        req = requests.get(f"{Settings.config.base_url}/terminals?offset=0&limit=999999999", cookies=Login_cookie())
        status = req.status_code
        print(req.content)
        content = json.loads(req.content.decode("utf-8"))
        print(content)
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            print(ResultCode)
            if ResultCode == 0:
                response = {"status": 'success', "message": 'success', "treminals": content}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return resp


def get_terminal_details(id):
    try:
        req = requests.get(f"{Settings.config.base_url}/terminals/{id}?apbflag=true&imageflag=true",
                           cookies=Login_cookie())
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        # print(f"{Settings.config.base_url}/{id}?apbflag=true&imageflag=true")
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                response = {"status": 'success', "message": 'success', "details": content}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return resp


def Edit_terminal(id, json_data):
    try:
        req = requests.put(f"{Settings.config.base_url}/terminals/{id}", cookies=Login_cookie(), json=json_data)
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        # print(f"{Settings.config.base_url}/{id}?apbflag=true&imageflag=true")
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                response = {"status": 'success', "message": 'success'}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return resp


def Get_Employee_details(employee_id):
    try:
        query = Users.query.filter_by(employee_id=employee_id).first()
        usr_schema = User_schema()
        output = usr_schema.dump(query)
        response = {"status": 'success', "message": 'Account details fetched successfully', "user_data": output}
        return response
    except Exception as e:
        response = {"status": 'error', "message": f'{str(e)}'}
        return response


def get_terminal_information(id):
    try:
        req = requests.get(f"{Settings.config.base_url}/terminals/{id}", cookies=Login_cookie())
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                return content
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return resp


def put_user_details(user_id, payload_json):
    req = requests.put(f"{Settings.config.base_url}/users/{user_id}",
                       cookies=Login_cookie(), json=payload_json)
    status = req.status_code
    content = json.loads(req.content.decode("utf-8"))
    if status == 200:
        ResultCode = content['Result']['ResultCode']
        if ResultCode == 0:
            response = {'status': 'success', "message": 'User updated successfully', 'user_details': content}
            return response
        else:
            response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
            return response
    else:
        response = {"status": 'error', "message": 'Something went wrong in alpetaServer while updating user details'}
        return response


def get_user_details(user_id):
    req = requests.get(f"{Settings.config.base_url}/users/{user_id}?fingerprint=false&face=false&picture=false",
                       cookies=Login_cookie())
    status = req.status_code
    content = json.loads(req.content.decode("utf-8"))
    if content.get('UserCardInfo'):
        content['UserCardInfo'][0]['UserID'] = user_id
    if status == 200:
        ResultCode = content['Result']['ResultCode']
        if ResultCode == 0:
            response = {'status': 'success', "message": 'success fetching user details', 'user_details': content}
            return response
        elif ResultCode == 4:
            response = {'status': 'success', "message": 'success fetching user finger details', 'user_finger': content}
            return response
        else:
            response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
            return response
    else:
        response = {"status": 'error', "message": 'Something went wrong in alpetaServer while fetching user details'}
        return response


def get_user_finger(user_id):
    req = requests.get(f"{Settings.config.base_url}/users/{user_id}/fingerPrint",
                       cookies=Login_cookie())
    status = req.status_code
    content = json.loads(req.content.decode("utf-8"))
    user_finger = content.get('UserFPInfo', [])
    if user_finger:
        for each in content['UserFPInfo']:
            each['UserID'] = user_id

    if status == 200:
        ResultCode = content['Result']['ResultCode']
        if ResultCode == 0:
            response = {'status': 'success', "message": 'success fetching user finger details', 'user_finger': content}
            return response
        elif ResultCode == 4:
            response = {'status': 'success', "message": 'success fetching user finger details', 'user_finger': content}
            return response
        else:
            response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
            return response
    else:
        response = {"status": 'error', "message": 'Something went wrong in alpetaServer while fetching user finger '
                                                  'details'}
        return response


def get_user_face(user_id):
    req = requests.get(f"{Settings.config.base_url}/users/{user_id}/faceWTInfo",
                       cookies=Login_cookie())
    status = req.status_code
    content = json.loads(req.content.decode("utf-8"))
    user_face = content.get('UserFaceWTInfo', [])
    if user_face:
        for each in content['UserFaceWTInfo']:
            each['UserID'] = user_id

    if status == 200:
        ResultCode = content['Result']['ResultCode']
        if ResultCode == 0:
            response = {'status': 'success', "message": 'success fetching user face details', 'user_face': content}
            return response
        elif ResultCode == 4:
            response = {'status': 'success', "message": 'success fetching user finger details', 'user_face': content}
            return response
        else:
            response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
            return response
    else:
        response = {"status": 'error', "message": 'Something went wrong in alpetaServer while fetching user face '
                                                  'details'}
        return response


def get_next_user_id():
    req = requests.get(f"{Settings.config.base_url}/users/initUserInfo", cookies=Login_cookie())
    status = req.status_code
    content = json.loads(req.content.decode("utf-8"))
    if status == 200:
        ResultCode = content['Result']['ResultCode']
        if ResultCode == 0:
            response = {'status': 'success', "message": 'success', 'user_id': content}
            return response
        else:
            response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
            return response
    else:
        response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
        return response


def Assign_userToTerMiNaLs(terminalID, userID):
    try:
        json_data = {"DownloadInfo": {"Total": 1, "Offset": 1}}
        req = requests.post(f"{Settings.config.base_url}/terminals/{terminalID}/users/{userID}", cookies=Login_cookie(),
                            json=json_data)
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                response = {'status': 'success', "message": 'success'}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return resp


def Delete_userToTerMiNaLs(terminalID, userID):
    try:
        json_data = {"DownloadInfo": {"Total": 1, "Offset": 1}}
        # v1 / terminals / 1 / users / 1
        req = requests.delete(f"{Settings.config.base_url}/terminals/{terminalID}/users/{userID}",
                              cookies=Login_cookie(),
                              json=json_data)
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                response = {'status': 'success', "message": 'success'}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return resp


def scanFingerPrint(terminal_id, alpeta_user_id, alpeta_figerprint_id):
    try:
        terminal_id = terminal_id
        alpeta_user_id = alpeta_user_id
        alpeta_figerprint_id = alpeta_figerprint_id

        req = requests.get(f"{Settings.config.base_url}/terminals/{terminal_id}/scan/fp_image?regcount=1&regtimeout=15"
                           f"&UserID={alpeta_user_id}&FingerID={alpeta_figerprint_id}", cookies=Login_cookie())
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                response = {"status": "success", "message": "Fingerprint captured successfully.",
                            "dmFPImage": content['dmFPImage']}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return resp


def scanFaceData(terminal_id):
    try:
        terminal_id = terminal_id
        req = requests.get(f"{Settings.config.base_url}/terminals/{terminal_id}/scan/facewt?capture_timeout=30"
                           , cookies=Login_cookie())
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                response = {"status": 'success', "message": 'Face data captured successfully.', "UserFaceWTInfo":
                    content['UserFaceWTInfo']}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        response = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return response


def scanCardData(terminal_id):
    try:
        terminal_id = terminal_id
        req = requests.get(f"{Settings.config.base_url}/terminals/{terminal_id}/scan/card", cookies=Login_cookie())
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                response = {"status": 'success', "message": 'Card captured successfully.',
                            "CardData": content["CardData"]}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        response = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return response


def Update_USER_ProfilePIC(alpeta_id, user_id, image_str, type):
    try:
        json_data = {"ImageType": type,
                     "Picture": image_str.split(",")[-1]}
        req = requests.put(f"{Settings.config.base_url}/users/{alpeta_id}/picture", cookies=Login_cookie(),
                           json=json_data)
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                Users.query.filter(Users.id == user_id).update(
                    {Users.profile_picture: image_str.split(",")[-1], Users.alpeta_updated_date: current_timestamp})
                db.session.flush()
                db.session.commit()
                download_to_terminal = User_terminals.Get_Terminals_by_userID_blacklist_status_(user_id)
                for each_terminal in download_to_terminal:
                    # download User to a specific terminal
                    Assign_userToTerMiNaLs(each_terminal, alpeta_id)

                response = {"status": 'success', "message": 'Profile picture updated'}
                return response
            else:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        response = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return response


def Get_USER_Info_from_TerminalID(id):
    try:
        req = requests.get(Settings.config.base_url + "/terminalUsers/" + str(id) + "/info?offset=0&limit=99",
                           cookies=Login_cookie())
        # req = requests.get("http://14.140.119.59:9004/v1/terminalUsers/2/info?offset=0&limit=99",cookies=Login_cookie())
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        # print(content)
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            # print(ResultCode)
            # print(hex(ResultCode))
            if ResultCode == 0:
                response = {"status": 'success', "message": 'success', "users": content}
                return response
            elif ResultCode != 0:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                # print(response)
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        response = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return response


def Delete_USER_from_Terminal(TerminalID, User_id):
    try:
        # req = requests.delete(Settings.config.base_url + "/terminals/"+ str(TerminalID)+"/users/" + str(User_id),cookies=Login_cookie())
        req = requests.delete(f"{Settings.config.base_url}/terminals/{TerminalID}/users/{User_id}",
                              cookies=Login_cookie())
        status = req.status_code
        content = json.loads(req.content.decode("utf-8"))
        if status == 200:
            ResultCode = content['Result']['ResultCode']
            if ResultCode == 0:
                response = {"status": 'success', "message": 'success'}
                return response
            elif ResultCode != 0:
                response = {'status': 'error', "message": 'alpetaServerError. Error Code: ' + str(ResultCode)}
                return response
        else:
            response = {"status": 'error', "message": 'Something went wrong in alpetaServer'}
            return response
    except Exception as e:
        response = {"status": 'error', "message": f'{str(e)} : Exception occured in alpetaServer'}
        return response


def FingerPrintmaster():
    try:
        All_data = Finger_masters.query.all()
        fingerprint_schema = Finger_masters_schema(many=True)
        output = fingerprint_schema.dump(All_data)
        return output
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured'}
        return resp


def DesignationMaster():
    try:
        All_data = Designations.query.filter(Designations.status != 'delete').all()
        designation_schema = Designations_schema(many=True)
        output = designation_schema.dump(All_data)
        return output
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured'}
        return resp


def ShiftMasters():
    try:
        All_data = Shifts.query.filter(Shifts.status != 'delete').all()
        shift_schema = Shifts_schema()
        shift_schema = Shifts_schema(many=True)
        output = shift_schema.dump(All_data)
        return output
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured'}
        return resp


def GroupMaster():
    try:
        All_data = Group.query.filter(Group.status != 'delete').all()
        GroupSchema = Group_schema()
        GroupSchema = Group_schema(many=True)
        output = GroupSchema.dump(All_data)
        final_data_list = []
        for i in output:
            i['terminal_Count'] = len(Group_terminals.GET_TerminalsDEtails_BY_GRoupID(i['id']))
            final_data_list.append(i)
        return final_data_list

    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured'}
        return resp


def SubAreaMasters():
    try:
        All_data = Subarea.query.filter(Subarea.status != 'delete').all()
        subarea_schema = Subarea_schema(many=True)
        output = subarea_schema.dump(All_data)
        return output
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured'}
        return resp


def VendorMaster():
    try:
        All_data = Vendors.query.filter(Vendors.status != 'delete').all()
        vendor_schema = Vendors_schema(many=True)
        output = vendor_schema.dump(All_data)
        return output
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured'}
        return resp


def DepartmentMaster():
    try:
        All_data = Department.query.filter(Department.status != 'delete').all()
        department_schema = Department_schema()
        department_schema = Department_schema(many=True)
        output = department_schema.dump(All_data)
        return output
    except Exception as e:
        resp = {"status": 'error', "message": f'{str(e)} : Exception occured'}
        return resp


# def UnitsBySubAreaID(subarea_id):
#     try:
#         All_data = Units.Units_by_SubAreaID(subarea_id)
#         unt_schema = Units_schema()
#         output = unt_schema.dump(All_data)
#         respone = {"status": 'success', "message": "Success", "units": output}
#         return respone
#     except Exception as e:
#         resp = {"status": 'error', "message": f'{str(e)} : Exception occured'}
#         return resp


def Paginate(data, page=1, page_size=10):
    if int(page) == 1:
        return data[0: int(page) + int(page_size) - 1]
    else:
        _page = int(page) - 1
        return data[_page * int(page_size):int(page) * int(page_size)]


def list_auth_info(data):
    auth_info = {"FAW": 9, "FP": 1, "CD": 2, "PW": 3}
    result = []

    data = json.loads(data)

    for each in range(7):
        if each < len(data["authentication_combination"]):
            result.append(auth_info[data["authentication_combination"][each]["value"]])
        else:
            result.append(0)

    if data["authentication_mode"] == "AND":
        result.append(len(data["authentication_combination"]))
    elif data["authentication_mode"] == "OR":
        result.append(0)

    return result

def query_processor(json_data,role_id):
    query = f"select * from users where role_id={role_id}"
    if json_data["status"] == "not deleted":
        query += " and status != 'delete'"
    if json_data["status"] == "active":
        query += " and status = 'active'"
    if json_data["status"] == "inactive":
        query += " and status = 'inactive'"
    if json_data["alpeta_user_id"] == "not null":
        query += " and alpeta_user_id is NOT Null"
    if json_data["alpeta_user_id"] == "null":
        query += " and alpeta_user_id is Null"
    if json_data["biometric_reg"] == True:
        query += " and alpeta_user_id is NOT NULL"
    if json_data["Alpeta_Reg_date"] == True:
        query += f" and (alpeta_created_date BETWEEN '{json_data['start_date']}' AND '{json_data['end_date']}')"
    return query

#
# def checkTerminalsFor_Dublicate(NewGroup_ID, TerminalID_List):
#     groupID = []
#     for i in TerminalID_List:
#         detls = Group_terminals.GET_GroupID_BY_terminalID(i)
#         groupID.extend(detls)
#     if NewGroup_ID in groupID:
#         return True
#     else:
#         return False


def Check_Parameter_Data(data):
    if not data:
        return None
    return data


#### Shifts fn

def Create_Shifts(name, code, shift_start_time, shift_end_time, status):
    return Shifts.Add_shifts(name, code, shift_start_time, shift_end_time, status)


def Update_Shifts(id, name, code, shift_start_time, shift_end_time, status):
    return Shifts.Update_Shifts(id, name, code, shift_start_time, shift_end_time, status)


def Status_update_Shifts(id, status):
    return Update_Shifts(id, status)


def Delete_Shifts(id):
    return Shifts.Delete(id)


# Designations

def Create_Designations(name, code, status):
    return Designations.Add_Designations(name, code, status)


def Update_Designations(id, name, code, status):
    return Designations.Update_Designation(id, name, code, status)


def Status_update_Designations(id, status):
    return Designations.Change_Status(id, status)


def Delete_Designations(id):
    return Designations.Delete(id)


# ## Units fn
#
# def Create_Units(subarea_id, code, name, description, status):
#     return Units.Add_Units(subarea_id, code, name, description, status)
#
#
# def Update_Units(id, subarea_id, code, name, description):
#     return Units.Update_Units(id, subarea_id, code, name, description)
#
#
# def Status_update_Units(id, status):
#     return Units.Change_Status(id, status)
#
#
# def Delete_Units(id):
#     return Units.Delete(id)


# # Sub area fn

def Create_Subarea(code, name, description, status):
    return Subarea.Add_Subarea(code, name, description, status, )


def Update_Subarea(id, code, name, description, status):
    return Subarea.Update_Subarea(id, code, name, description, status)


def Status_update_Subarea(id, status):
    return Subarea.Change_Status(id, status)


def Delete_Subarea(id):
    return Subarea.Delete(id)
