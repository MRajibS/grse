import csv
import time
import sys
import traceback
import os
import helpers
from helpers import *
from app import *
from app.Models import *
from flask.views import MethodView
from flask import Blueprint, send_file, url_for
import copy
from datetime import datetime

current_timestamp = datetime.now()
Blacklist_view = Blueprint('blacklist_view', __name__)


def convert_database_to_alpeta_formate(user_finger, _id):
    UserFPdata = []
    for i in user_finger:
        FP_obj1 = {"FingerID": i['fingerid'], "MinConvType": 3, "Reserved": 0, "TemplateIndex": 1,
                   "TemplateData": i['template1'], "UserID": _id}
        FP_obj2 = {"FingerID": i['fingerid'], "MinConvType": 3, "Reserved": 0,
                   "TemplateIndex": 2, "TemplateData": i['template2'], "UserID": _id}
        UserFPdata.append(FP_obj1)
        UserFPdata.append(FP_obj2)
    return UserFPdata


class CreateBlacklist(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/CreateBlacklist.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            _id = request_data['id']
            user_id = request_data['user_id']
            user_id_alpeta = request_data['alpeta_id']
            terminal_id = request_data['terminal_id']
            block_from = request_data['block_from']
            block_to = request_data['block_to']

            is_block = 1  # Inactive
            user_ = Users.FetchUSerDetails_By_ID(user_id)  # get user details from database
            user_finger = User_fingerprints.FetchUserFingerPrintDetails_By_ID(user_id)  # get user finger from database
            user_finger = convert_database_to_alpeta_formate(user_finger, user_id)  # convert to Alp-eta structure
            user_face = User_facedatas.FetchUserfacedatas_By_ID(user_id)  # get user face from database
            if user_:
                user_details_alpeta = get_user_details(user_id_alpeta)  # get user details Alp-eta
                user_finger_alpeta = get_user_finger(user_id_alpeta)  # get user finger details Alp-eta
                user_face_alpeta = get_user_face(user_id_alpeta)  # get user face details Alp-eta
                if user_details_alpeta['status'] == 'success':
                    user_info = user_details_alpeta['user_details']
                    user_info['UserInfo']['AuthInfo'] = list_auth_info(user_["auth_comb"]) if user_["auth_comb"] else [
                        9, 2, 0, 0, 0, 0, 0, 2]
                    user_info['UserInfo']["Picture"] = user_["profile_picture"]
                    card_info = user_info.get('UserCardInfo', [])
                    if card_info:
                        user_info['UserCardInfo'][0]['UserID'] = user_id
                    user_info['UserFPInfo'] = user_finger_alpeta['user_finger'].get('UserFPInfo', user_finger)
                    user_info["UserFaceWTInfo"] = user_face_alpeta['user_face'].get("UserFaceWTInfo", [{
                        "UserID": user_face.get("user_id", ""),
                        "TemplateSize": user_face.get("templatesize", ""),
                        "TemplateData": user_face.get("templatedata", ""),
                        "TemplateType": user_face.get("templatetype", "")
                    }])
                    # Memory copy of the object
                    user_info_copy = copy.deepcopy(user_info)
                    user_info_copy['UserInfo']["BlackList"] = is_block
                    user_info_copy['UserInfo']['CreateDate'] = block_from if block_from \
                        else str(current_timestamp)
                    user_info_copy['UserInfo']["ExpireDate"] = block_to if block_to \
                        else str(datetime.strptime("2099-12-06 10:33:06", "%Y-%m-%d %H:%M:%S"))
                    user_info_copy['UserInfo']["UsePeriodFlag"] = 1
                    update_user_details = put_user_details(user_id_alpeta, user_info_copy)
                    if update_user_details['status'] == 'success':
                        # download User to a specific terminal
                        assign_user = Assign_userToTerMiNaLs(terminal_id, user_id_alpeta)
                        if assign_user['status'] == 'success':
                            # update user back to the Alpeta
                            update_user_details_back = put_user_details(user_id_alpeta, user_info)
                            try:
                                data = User_terminals.Update_User_terminals(_id,
                                                                            user_id,
                                                                            terminal_id,
                                                                            is_block,
                                                                            datetime.strptime(block_from,
                                                                                              "%Y-%m-%d %H:%M:%S"),
                                                                            datetime.strptime(block_to,
                                                                                              "%Y-%m-%d %H:%M:%S"),
                                                                            current_timestamp)
                                respone = {"status": 'success',
                                           "message": "User Terminal database updated successfully &"
                                                      " User Inactivated/Blacklisted and "
                                                      "downloaded ",
                                           "user_terminals": {
                                               "Database status": "Database updated successfully" if data is None else data,
                                               "User details": update_user_details_back}}
                                return make_response(jsonify(respone)), 200
                            except Exception as e:
                                response = {"status": 'error', "message": f'{str(e)}'}
                                return make_response(jsonify(response)), 200
                        else:
                            respone = {"status": 'success', "message": "User Inactivated/Blacklisted successfully but "
                                                                       "failed to download to a specific terminal ",
                                       "user_update_details": update_user_details}
                            return make_response(jsonify(respone)), 200
                    else:
                        respone = {"status": 'error', "message": "User Inactivated/Blacklisted unsuccessfully ",
                                   "user_details_alpeta": "Error while Blacklisting user " + str(update_user_details)}
                        return make_response(jsonify(respone)), 200
                else:
                    respone = {"status": 'error', "message": "Error fetching user details or user not registered in "
                                                             "server",
                               "user_details_alpeta": user_details_alpeta}
                    return make_response(jsonify(respone)), 200

            else:
                respone = {"status": 'error', "message": "Error fetching user details or user not registered in DB",
                           "user_details_alpeta": user_}
                return make_response(jsonify(respone)), 200

        except Exception as e:
            traceback.print_exc()
            response = {"status": 'error', "message": f'{str(e)}'}
            return make_response(jsonify(response)), 200


class RevertBlacklist(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/RevertBlacklist.yaml', methods=['POST'])
    def post(self):
        try:
            request_data = request.get_json(force=True)
            _id = request_data['id']
            user_id = request_data['user_id']
            terminal_id = request_data['terminal_id']
            block_from = request_data['block_from']
            block_to = request_data['block_to']
            user_id_alpeta = request_data['alpeta_id']
            is_block = 0  # Active
            user_ = Users.FetchUSerDetails_By_ID(user_id)  # get user details from database
            user_finger = User_fingerprints.FetchUserFingerPrintDetails_By_ID(user_id)  # get user finger from database
            user_finger = convert_database_to_alpeta_formate(user_finger, user_id)  # convert to Alp-eta structure
            user_face = User_facedatas.FetchUserfacedatas_By_ID(user_id)  # get user face from database
            if user_:
                user_details_alpeta = get_user_details(user_id_alpeta)  # get user details Alp-eta
                user_finger_alpeta = get_user_finger(user_id_alpeta)  # get user finger details Alp-eta
                user_face_alpeta = get_user_face(user_id_alpeta)  # get user face details Alp-eta
                if user_details_alpeta['status'] == 'success':
                    user_info = user_details_alpeta['user_details']
                    user_info['UserInfo']['AuthInfo'] = list_auth_info(user_["auth_comb"]) if user_["auth_comb"] else [
                        9, 2, 0, 0, 0, 0, 0, 2]
                    user_info['UserInfo']["Picture"] = user_["profile_picture"]
                    card_info = user_info.get('UserCardInfo', [])
                    if card_info:
                        user_info['UserCardInfo'][0]['UserID'] = user_id
                    user_info['UserFPInfo'] = user_finger_alpeta['user_finger'].get('UserFPInfo', user_finger)
                    user_info["UserFaceWTInfo"] = user_face_alpeta['user_face'].get("UserFaceWTInfo", [{
                        "UserID": user_face.get("user_id", ""),
                        "TemplateSize": user_face.get("templatesize", ""),
                        "TemplateData": user_face.get("templatedata", ""),
                        "TemplateType": user_face.get("templatetype", "")
                    }])
                    user_info_copy = copy.deepcopy(user_info)
                    user_info_copy['UserInfo']["BlackList"] = is_block
                    user_info_copy['UserInfo']['CreateDate'] = block_from if block_from \
                        else str(current_timestamp)
                    user_info_copy['UserInfo']["ExpireDate"] = block_to if block_to \
                        else str(datetime.strptime("2099-12-06 10:33:06", "%Y-%m-%d %H:%M:%S"))
                    user_info_copy['UserInfo']["UsePeriodFlag"] = 0
                    update_user_details = put_user_details(user_id_alpeta, user_info_copy)
                    if user_ and user_["alpeta_user_id"]:
                        if update_user_details['status'] == 'success':
                            assign_user = Assign_userToTerMiNaLs(terminal_id, user_id_alpeta)
                            if assign_user['status'] == 'success':
                                try:
                                    data = User_terminals.Update_User_terminals(_id,
                                                                                user_id,
                                                                                terminal_id,
                                                                                is_block,
                                                                                datetime.strptime(block_from,
                                                                                                  "%Y-%m-%d %H:%M:%S"),
                                                                                datetime.strptime(block_to,
                                                                                                  "%Y-%m-%d %H:%M:%S"),
                                                                                current_timestamp)
                                    respone = {"status": 'success',
                                               "message": "User Terminal database updated successfully &"
                                                          " User activated/undo Blacklisting and "
                                                          "downloaded ",
                                               "user_terminals":
                                                   {
                                                       "Database status": "Database updated successfully" if data is None else data,
                                                       "User details": update_user_details}}
                                    return make_response(jsonify(respone)), 200
                                except Exception as e:
                                    response = {"status": 'error', "message": f'{str(e)}'}
                                    return make_response(jsonify(response)), 200


                            else:
                                respone = {"status": 'success',
                                           "message": "User activated/undo Blacklisting successfully but "
                                                      "failed to download to a specific terminal ",
                                           "user_update_details": update_user_details}
                                return make_response(jsonify(respone)), 200
                        else:
                            respone = {"status": 'success', "message": "User activated unsuccessfully ",
                                       "user_details_alpeta": "Error while activating user from Blacklist " + str(
                                           update_user_details)}
                            return make_response(jsonify(respone)), 200
                    else:
                        respone = {"status": 'error',
                                   "message": "Error fetching user details or user not registered in "
                                              "server",
                                   "user_details_alpeta": user_details_alpeta}
                        return make_response(jsonify(respone)), 200
            else:
                respone = {"status": 'error', "message": "Error fetching user details or user not registered in DB",
                           "user_details_alpeta": user_}
                return make_response(jsonify(respone)), 200

        except TypeError as e:
            respone = {"TypeError": f'{str(e)}'}
            return make_response(jsonify(respone)), 200
        except Exception as e:
            response = {"status": 'error', "message": f'{str(e)}'}
            return make_response(jsonify(response)), 200


def terminal_type(type, time):
    if type == "auto":
        if str(time) < "12:00:00":
            return "P10"
        else:
            return "P20"
    elif type == "in":
        return "P10"
    else:
        return "P20"


class Get_Auth_log(MethodView):
    @cross_origin(supports_credentials=True)
    @swag_from('apidocs/Authlog.yaml', methods=['GET'])
    def get(self, Date):
        try:
            current_timestamp = datetime.now()
            end_date_time = Date + "23:59:59"
            start_date_time = Date + "00:00:00"
            print(start_date_time, end_date_time)
            Get_auth = get_auth(str(start_date_time), str(end_date_time))
            user_in = list()
            user_out = list()
            if Get_auth['Authlog']['AuthLogList']:
                for each in Get_auth['Authlog']['AuthLogList']:
                    if each["AuthResult"] == 0:
                        terminal_info = str(Terminals.FetchTerminals_By_ID(each["TerminalID"])["terminal_type"])
                        if each['UniqueID'] not in user_in and terminal_type(terminal_info,
                                                                             each['EventTime'].split(" ")[1]) \
                                == "P10":
                            user_in.append(each['UniqueID'])
                            with open(r'static/Attendance_' + str(current_timestamp).replace(" ", "") + ".csv", 'a',
                                      newline='') as csvfile:
                                fieldnames = ['PERNR', 'TIMR6', 'CHOIC', 'LDATE', 'LTIME', 'SATZA', 'TERMINAL_id',
                                              'SERVER_TIME']
                                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                                if csvfile.tell() == 0:
                                    writer.writeheader()
                                event_time = min([each_['EventTime'].split(" ")[1] for each_ in
                                                  Get_auth['Authlog']['AuthLogList']
                                                  if each_['UniqueID'] == each['UniqueID'] and
                                                  terminal_type(terminal_info, each['EventTime'].split(" ")[1]) \
                                                  == "P10"]) if terminal_type(terminal_info,
                                                                              each['EventTime'].split(
                                                                                  " ")[1]) == "P10" else 0
                                server_time = each['EventTime'].split(" ")[0] + " " + min(
                                    [each_['EventTime'].split(" ")[1] for each_ in
                                     Get_auth['Authlog']['AuthLogList']
                                     if each_['UniqueID'] == each['UniqueID'] and
                                     terminal_type(terminal_info, each['EventTime'].split(" ")[1])
                                     == "P10"]) if \
                                    terminal_type(terminal_info, each['EventTime'].split(" ")[1]) == "P10" else 0
                                event_date = datetime.strptime(each['EventTime'].split(" ")[0], '%Y-%m-%d')
                                server_time = datetime.strptime(server_time, '%Y-%m-%d %H:%M:%S')
                                writer.writerow({'PERNR': each['UniqueID'], 'TIMR6': 'X', "CHOIC": "2011",
                                                 "LDATE": event_date.strftime("%d.%m.%Y"),
                                                 "LTIME": event_time,
                                                 "SATZA": terminal_type(terminal_info, each['EventTime'].split(" ")[1]),
                                                 "TERMINAL_id": Terminals.FetchTerminals_By_ID(each["TerminalID"])[
                                                     "short_code"],
                                                 "SERVER_TIME": server_time.strftime("%d.%m.%Y %H:%M:%S")})
                        elif each['UniqueID'] not in user_out and terminal_type(terminal_info,
                                                                                each['EventTime'].split(" ")[1]) \
                                == "P20":
                            user_out.append(each['UniqueID'])
                            with open(r'static/Attendance_' + str(current_timestamp).replace(" ", "") + ".csv", 'a',
                                      newline='') as csvfile:
                                fieldnames = ['PERNR', 'TIMR6', 'CHOIC', 'LDATE', 'LTIME', 'SATZA', 'TERMINAL_id',
                                              'SERVER_TIME']
                                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                                if csvfile.tell() == 0:
                                    writer.writeheader()
                                event_time = max([each_['EventTime'].split(" ")[1] for each_ in
                                                  Get_auth['Authlog']['AuthLogList']
                                                  if each_['UniqueID'] == each['UniqueID'] and
                                                  terminal_type(terminal_info, each['EventTime'].split(" ")[1])
                                                  == "P20"]) if terminal_type(terminal_info,
                                                                              each['EventTime'].split(" ")[
                                                                                  1]) == "P20" else 0
                                server_time = each['EventTime'].split(" ")[0] + " " + max(
                                    [each_['EventTime'].split(" ")[1] for each_ in
                                     Get_auth['Authlog']['AuthLogList']
                                     if each_['UniqueID'] == each['UniqueID'] and
                                     terminal_type(terminal_info, each['EventTime'].split(" ")[1])
                                     == "P20"]) if terminal_type(terminal_info,
                                                                 each['EventTime'].split(" ")[1]) == "P20" else 0
                                event_date = datetime.strptime(each['EventTime'].split(" ")[0], '%Y-%m-%d')
                                server_time = datetime.strptime(server_time, '%Y-%m-%d %H:%M:%S')
                                writer.writerow({'PERNR': each['UniqueID'], 'TIMR6': 'X', "CHOIC": "2011",
                                                 "LDATE": event_date.strftime("%d.%m.%Y"),
                                                 "LTIME": event_time,
                                                 "SATZA": terminal_type(terminal_info, each['EventTime'].split(" ")[1]),
                                                 "TERMINAL_id": Terminals.FetchTerminals_By_ID(each["TerminalID"])[
                                                     "short_code"],
                                                 "SERVER_TIME": server_time.strftime("%d.%m.%Y %H:%M:%S")})
                PATH = "static/Attendance_" + str(current_timestamp).replace(" ", "") + '.csv'
                respone = {"status": 'Success', "message": "Authlog exported",
                           "Authlog": f"{Settings.config.download_url}/{PATH}"}
                #current_timestamp = datetime.now()
                return make_response(jsonify(respone)), 200

            else:
                respone = {"status": 'Error', "message": "Authlog not found for the following date",
                           "Authlog": "Authlog not exported"}
                return make_response(jsonify(respone)), 200

        except Exception as e:
            import traceback
            traceback.print_exc(e)
            response = {"status": 'error', "message": f'{str(e)}'}
            return make_response(jsonify(response)), 200
        finally:
            time.sleep(5)



# # # Creating View Function/Resources
CreateBlacklist = CreateBlacklist.as_view("CreateBlacklist")
RevertBlacklist = RevertBlacklist.as_view("RevertBlacklist")
Get_Auth_log = Get_Auth_log.as_view("Authlog")

# # # adding routes to the Views we just created
Blacklist_view.add_url_rule('/blacklist', view_func=CreateBlacklist, methods=['POST'])
Blacklist_view.add_url_rule('/revert_blacklist', view_func=RevertBlacklist, methods=['POST'])
Blacklist_view.add_url_rule('/auth_log/<Date>', view_func=Get_Auth_log, methods=['GET'])
